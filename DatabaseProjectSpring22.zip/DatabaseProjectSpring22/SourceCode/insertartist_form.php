<?php

include 'proj_header.txt'; ?>

<h1>Add New Artist</h1>
<p>Use the table provided below to create new Artist</p>

        <form action="insertartist.php" method="post">
            <label>Artist ID:</label> <input type="text" name="a_id"/><br>
            <label>Artist Name: </label><input type="text" name="a_name"/><br>
            <label>Genre ID:</label> <input type="text" name="g_id"/><br>
            <input type="Submit" value= "Insert"/><input type="Reset"/>
        </form>
        <hr>
        <h3>Artists</h3>
<?php
include 'db.php';

try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        $stmt = $conn->query("select * from Artist;");
        //PDO::FETCH_ASSOC: returns an array indexed by column name as returned in your result set
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

}
catch(PDOException $e) {
   die("Could not connect to the database $dbname :" . $e->getMessage());
}


echo "<table border=1>\n";
echo "<tr><th>Artist ID</th><th>Artist Name</th></tr>\n";

while ($row = $stmt->fetch()) {
      printf("<tr><td>%s</td> <td>%s</td> </tr>\n", $row['a_id'], $row['a_name']);
}
echo "</table>\n";
$conn = null;
  
?>

<hr>
<h3>Genres</h3>
      
<?php

try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        $stmt = $conn->query("select * from Genre;");
        //PDO::FETCH_ASSOC: returns an array indexed by column name as returned in your result set
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

}
catch(PDOException $e) {
   die("Could not connect to the database $dbname :" . $e->getMessage());
}
  
  
echo "<table border=1>\n";
echo "<tr><th>Genre ID</th><th>Genre Name</th></tr>\n";

while ($row = $stmt->fetch()) {
      printf("<tr><td>%s</td> <td>%s</td> </tr>\n", $row['g_id'], $row['g_name']);
}
echo "</table>\n";
$conn = null;
        
include 'proj_footer.txt';
        
?>
