<?php include 'proj_header.txt'; ?>
<?php

include_once 'db.php';

$c_id=$_POST['c_id'];
$c_date=$_POST['c_date'];
$c_name=$_POST['c_name'];
$a_id=$_POST['a_id'];
$v_id=$_POST['v_id'];


try {
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	
	#use prepared statment with named placeholders :first, :last, :title, :age, :yos, :salary, :email.
	$sql = "insert into Concert (c_id, c_date, c_name, a_id, v_id) values(:c_id, :c_date, :c_name, :a_id, :v_id)";
	$stmt = $conn->prepare($sql);
	$stmt->bindParam(':c_id', $c_id, PDO::PARAM_INT);
	$stmt->bindParam(':c_date', $c_date);
	$stmt->bindParam(':c_name', $c_name);
	$stmt->bindParam(':a_id', $a_id, PDO::PARAM_INT);
	$stmt->bindParam(':v_id', $v_id, PDO::PARAM_INT);

	if($stmt->execute()){
		$rows_affected = $stmt->rowCount();
        	echo "<h2>".$rows_affected." row added sucessfully!</h2>";
		$stmt = $conn->query("SELECT * FROM Concert;");

		//PDO::FETCH_NUM: returns an array indexed by column number as returned in your result set, starting at column 0 
		$stmt->setFetchMode(PDO::FETCH_NUM);
		echo "<table border=\"1\">\n";
		echo "<tr><td>Concert ID</td><td>Concert Date</td><td>Concert Name</td><td>Artist ID</td><td>Venue ID</td></tr>\n";
		while ($row = $stmt->fetch()) {
     			printf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n", 	$row[0], $row[1], $row[2], $row[3], $row[4]);
		}
       		echo "</table>\n";
	}
	else
	{
	 	echo "Insertion failed: (" . $conn->errno . ") " . $conn->error;
	}

	$conn = null;
}
catch(PDOException $e) {
	die("Could not connect to the database $dbname :" . $e->getMessage());
}


?>
<?php include 'proj_footer.txt'; ?>
                
                        
                


