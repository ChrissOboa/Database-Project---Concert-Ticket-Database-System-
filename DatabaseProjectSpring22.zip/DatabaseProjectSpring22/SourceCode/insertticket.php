<?php include 'proj_header.txt'; ?>
<?php

include_once 'db.php';

$t_id=$_POST['t_id'];
$t_seat=$_POST['t_seat'];
$t_Purchase_Date=$_POST['t_Purchase_Date'];
$c_id=$_POST['c_id'];
$tc_id=$_POST['tc_id'];


try {
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	
	#use prepared statment with named placeholders :first, :last, :title, :age, :yos, :salary, :email.
	$sql = "insert into Ticket (t_id, t_seat, t_Purchase_Date, c_id, tc_id) values(:t_id, :t_seat, :t_Purchase_Date, :c_id, :tc_id)";
	$stmt = $conn->prepare($sql);
	$stmt->bindParam(':t_id', $t_id, PDO::PARAM_INT);
	$stmt->bindParam(':t_seat', $t_seat);
	$stmt->bindParam(':t_Purchase_Date', $t_Purchase_Date);
	$stmt->bindParam(':c_id', $c_id, PDO::PARAM_INT);
	$stmt->bindParam(':tc_id', $tc_id, PDO::PARAM_INT);

	if($stmt->execute()){
		$rows_affected = $stmt->rowCount();
        	echo "<h2>".$rows_affected." row added sucessfully!</h2>";
		$stmt = $conn->query("SELECT * FROM Ticket;");

		//PDO::FETCH_NUM: returns an array indexed by column number as returned in your result set, starting at column 0 
		$stmt->setFetchMode(PDO::FETCH_NUM);
		echo "<table border=\"1\">\n";
		echo "<tr><td>Ticket ID</td><td>Seat</td><td>Ticket Purchase Date</td><td>Concert ID</td><td>Ticket Category ID</td></tr>\n";
		while ($row = $stmt->fetch()) {
     			printf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n", 	$row[0], $row[1], $row[2], $row[3], $row[4]);
		}
       		echo "</table>\n";
	}
	else
	{
	 	echo "Insertion failed: (" . $conn->errno . ") " . $conn->error;
	}

	$conn = null;
}
catch(PDOException $e) {
	die("Could not connect to the database $dbname :" . $e->getMessage());
}


?>
<?php include 'proj_footer.txt'; ?>