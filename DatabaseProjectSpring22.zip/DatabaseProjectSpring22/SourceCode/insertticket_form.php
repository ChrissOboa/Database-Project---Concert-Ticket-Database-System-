
 <?php include 'proj_header.txt'; ?>
 
 <h1>Add New Concert Ticket</h1>
<p>Use the tables provided below to create new concerts</p>
        <form action="insertticket.php" method="post">
            <label>Ticket ID:</label> <input type="text" name="t_id"/><br>
            <label>Ticket Seat: </label> <input type="text" name="t_seat"/><br>
            <label>Ticket Purchase Date:</label> <input type="text" name="t_Purchase_Date"/><br>
            <label>Concert ID: </label><input type="text" name="c_id"/><br>
            <label>Ticket Category ID:</label> <input type="text" name="tc_id"/><br>
            <input type="Submit" value= "Insert"/><input type="Reset"/>
        </form>
        
<hr>

<h1>Concerts</h1>

<?php 

include 'db.php';

try {
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	$stmt = $conn->query("select distinct c.c_id, c.c_name, c.c_date, v.v_name, a.a_name from Concert as c, Venue as v, Artist as a where c.v_id = v.v_id and c.a_id = a.a_id;");
	//PDO::FETCH_ASSOC: returns an array indexed by column name as returned in your result set 
	$stmt->setFetchMode(PDO::FETCH_ASSOC);
	
}
catch(PDOException $e) {
   die("Could not connect to the database $dbname :" . $e->getMessage());
}


echo "<table border=1>\n";
echo "<tr><th>Concert ID</th><th>Concert Name</th><th>Concert Date</th><th>Venue Name</th><th>Artist Name</th></tr>\n";
 
while ($row = $stmt->fetch()) {
      printf("<tr><td>%s</td><td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> </tr>\n", $row['c_id'], $row['c_name'], $row['c_date'], $row['v_name'], $row['a_name']);
}
echo "</table>\n";
$conn = null;

?>

<hr>

<h1>Ticket Categories</h1>

<?php 

include 'db.php';

try {
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	$stmt = $conn->query("select * from Ticket_Category");
	//PDO::FETCH_ASSOC: returns an array indexed by column name as returned in your result set 
	$stmt->setFetchMode(PDO::FETCH_ASSOC);
	
}
catch(PDOException $e) {
   die("Could not connect to the database $dbname :" . $e->getMessage());
}


echo "<table border=1>\n";
echo "<tr><th>Ticket Category</th><th>Ticket Category ID</th><th>Ticket Category Price Range (in USD $)</th></tr>\n";
 
while ($row = $stmt->fetch()) {
      printf("<tr><td>%s</td> <td>%s</td> <td>%s</td></tr>\n", $row['tc_Desc'], $row['tc_id'], $row['tc_Price_Range']);
}
echo "</table>\n";
$conn = null;

?>
 <?php include 'proj_footer.txt'; ?>


