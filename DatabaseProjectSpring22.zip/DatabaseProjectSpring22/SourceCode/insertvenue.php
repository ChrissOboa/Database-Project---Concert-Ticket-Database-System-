<?php include 'proj_header.txt'; ?>
<?php
        
include_once 'db.php';
        
$v_id=$_POST['v_id'];
$v_name=$_POST['v_name'];
$v_Address=$_POST['v_Address'];
$v_city=$_POST['v_city'];
$v_capacity=$_POST['v_capacity'];

                
try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
                
        #use prepared statment with named placeholders
        $sql = "insert into Venue (v_id, v_name, v_Address, v_city, v_capacity) values(:v_id, :v_name, :v_Address, :v_city, :v_capacity)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':v_id', $v_id, PDO::PARAM_INT);
        $stmt->bindParam(':v_name', $v_name, PDO::PARAM_STR);
        $stmt->bindParam(':v_Address', $v_Address, PDO::PARAM_STR);
        $stmt->bindParam(':v_city', $v_city, PDO::PARAM_STR);
        $stmt->bindParam(':v_capacity', $v_capacity, PDO::PARAM_INT);

        if($stmt->execute()){
                $rows_affected = $stmt->rowCount();
                echo "<h2>".$rows_affected." row added sucessfully!</h2>";
                $stmt = $conn->query("SELECT * FROM Venue;");
 
                //PDO::FETCH_NUM: returns an array indexed by column number as returned in your result set, starting at column 0
                $stmt->setFetchMode(PDO::FETCH_NUM);
                echo "<table border=\"1\">\n";
                echo "<tr><td>Venue ID</td><td>Venue Name</td><td>Address</td><td>City</td><td>Venue Capacity</td></tr>\n";
                while ($row = $stmt->fetch()) {
                        printf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",    $row[0], $row[1], $row[2], $row[3], $row[4]);
                }
                echo "</table>\n";
    }
        else
        {
                echo "Insertion failed: (" . $conn->errno . ") " . $conn->error;
        }

        $conn = null;
}
catch(PDOException $e) {
        die("Could not connect to the database $dbname :" . $e->getMessage());
}
                
                
?>
<?php include 'proj_footer.txt'; ?>
                

