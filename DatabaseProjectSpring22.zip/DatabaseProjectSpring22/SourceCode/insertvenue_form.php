<?php

include 'proj_header.txt'; ?>

<h1>Add New Venue</h1>
<p>Use the tables provided below to create new venues</p>

        <form action="insertvenue.php" method="post">
            <label>Venue ID:</label> <input type="text" name="v_id"/><br>
            <label>Venue Name: </label> <input type="text" name="v_name"/><br>
            <label>Address:</label> <input type="text" name="v_Address" /><br>
            <label>City: </label><input type="text" name="v_city"/><br>
            <label>Venue Capacity:</label> <input type="text" name="v_capacity"/><br>
            <input type="Submit" value= "Insert"/><input type="Reset"/>
        </form>
        <hr>
<h3>Venue</h3>
<?php
include 'db.php';

try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
        $conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        $stmt = $conn->query("select * from Venue;");
        //PDO::FETCH_ASSOC: returns an array indexed by column name as returned in your result set
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

}
catch(PDOException $e) {
   die("Could not connect to the database $dbname :" . $e->getMessage());
}
echo "<table border=1>\n";
echo "<tr><th>Venue ID</th><th>Venue Name</th><th>Address</th><th>City</th><th>Venue Capacity</th></tr>\n";

while ($row = $stmt->fetch()) {
      printf("<tr><td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> </tr>\n", $row['v_id'], $row['v_name'], $row['v_Address'], $row['v_city'], $row['v_capacity']);

}
echo "</table>\n";
$conn = null;
  
?>

<?php include 'proj_footer.txt'; ?>
