 <?php include 'proj_header.txt'; ?>
      <h1>Welcome!</h1>
      <p>This is a Database Management System project created by Chriss Oboa, Elijah Olsson, and Nathaniel Row.</p>
      <hr>
      <h3></h3>
      <p></p>

 <?php include 'proj_footer.txt'; ?>
