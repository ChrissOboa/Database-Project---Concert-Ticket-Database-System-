<?php include 'proj_header.txt'; ?>



<h1>Customer Tickets</h1>

<?php 

include 'db.php';

try {
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	$stmt = $conn->query("select distinct cust.username, co.delivery_email, t.t_id, tc.tc_Desc, t.t_seat, c.c_name, t.t_Purchase_Date, co.total_price from Ticket as t, Order_Ticket as ot, Customer as cust, Concert as c, Customer_Order as co, Ticket_Category as tc where t.t_id = ot.t_id and ot.cust_id = cust.cust_id and c.c_id = t.c_id and cust.cust_id = co.cust_id and tc.tc_id = t.tc_id;");
	//PDO::FETCH_ASSOC: returns an array indexed by column name as returned in your result set 
	$stmt->setFetchMode(PDO::FETCH_ASSOC);
	
}
catch(PDOException $e) {
   die("Could not connect to the database $dbname :" . $e->getMessage());
}


echo "<table border=1>\n";
echo "<tr><th>Customer Username</th><th>Customer Email</th><th>Ticket ID</th><th>Ticket Category</th><th>Seat</th><th>Concert Name</th><th>Purchase Date</th><th>Purchase Price</th></tr>\n";
 
while ($row = $stmt->fetch()) {
      printf("<tr><td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> </tr>\n", $row['username'], $row['delivery_email'], $row['t_id'], $row['tc_Desc'],$row['t_seat'], $row['c_name'], $row['t_Purchase_Date'], $row['total_price']);
}
echo "</table>\n";
$conn = null;

?>

 <?php include 'proj_footer.txt'; ?>



