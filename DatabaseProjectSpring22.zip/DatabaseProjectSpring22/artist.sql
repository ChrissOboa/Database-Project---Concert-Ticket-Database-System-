insert into Artist	values (101,	'Chris Brown',  16);
insert into Artist	values (215,    'Taylor Swift', 1);
insert into Artist	values (102,	'Billie Eilish',    12);
insert into Artist	values (305,	'50 Cent',	3);
insert into Artist	values (201,	'Drake',	16);
