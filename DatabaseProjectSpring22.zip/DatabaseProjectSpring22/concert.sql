insert into Concert values (1088761,	'2022-08-01', 'Coachella',  201,   89373);
insert into Concert values (2157475,    '2022-10-21', 'Fall Festival',  215,  10835);
insert into Concert	values (1046462,	'2022-11-15',    'Veteran Day Special',    305,   10050);
insert into Concert	values (3056325,	'2023-01-03',    'New Year Festival',	 102,  10835);
insert into Concert	values (2046561,	'2023-02-15',    'Valentine Concert',	101,   89373);