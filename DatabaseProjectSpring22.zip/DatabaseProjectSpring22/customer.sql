insert into Customer	values (10209,	'cfo2@hood.edu',    'Chriss20', 'hood2022');
insert into Customer	values (10409,	'nar2@hood.edu',    'Nathan70', 'Dhall2023');
insert into Customer	values (10255,	'eno1@hood.edu',    'Elijah97', 'Hodson347');
