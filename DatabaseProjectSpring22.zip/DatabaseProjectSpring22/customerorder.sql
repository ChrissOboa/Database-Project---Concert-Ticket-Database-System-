insert into Customer_Order	values (8270,   11:36:35,   2022-04-28,   50,   'Gaithersburg, MD', 'cfo2@hood.edu',    10209);
insert into Customer_Order	values (2430,   15:22:49,   2021-12-11,   700,  'Frederick, MD',    'nar2@hood.edu',    10409);
insert into Customer_Order	values (5460,   03:46:26,   2022-01-23,   700,  'Frederick, MD',    'eno1@hood.edu',    10255);