insert into Genre	values (1,	'POP');
insert into Genre	values (2,	'R&B');
insert into Genre	values (3,	'Rap');
insert into Genre	values (4,	'HipHop');
insert into Genre	values (5,	'Trap');
insert into Genre	values (6,	'Rock');
insert into Genre	values (7,	'EDM');
insert into Genre	values (8,	'Soul');
insert into Genre	values (9,	'Gospel');
insert into Genre	values (10,	'Indie');
insert into Genre	values (11,	'Heavy Metal');
insert into Genre	values (12,	'Alternative');
insert into Genre	values (13,	'Afrobeat');
insert into Genre	values (14,	'Dancehall');
insert into Genre	values (15,	'Reggaeton');
insert into Genre	values (16,	'HipHop/R&B');
insert into Genre	values (17,	'Pop/Rock');

insert into Customer	values (10209,	'cfo2@hood.edu',    'Chriss20', 'hood2022');
insert into Customer	values (10409,	'nar2@hood.edu',    'Nathan70', 'Dhall2023');
insert into Customer	values (10255,	'eno1@hood.edu',    'Elijah97', 'Hodson347');
insert into Customer	values (10346,	'efb6@hood.edu',    'Elizabeth23', 'Whitaker4505');
insert into Customer	values (10499,	'sac5@hood.edu',    'Sean43', 'Shriner43');
insert into Customer	values (10259,	'lid6@hood.edu',    'Lily54', 'Apple21');

insert into Ticket_Category	values (1,	'VIP',    '3000 to 10000');
insert into Ticket_Category	values (2,	'General Admission',    '50 to 120');
insert into Ticket_Category	values (3,	'Early Birds',    '40 to 49');
insert into Ticket_Category	values (4,	'Reserved seating',    '600 to 1000');
insert into Ticket_Category	values (5,	'Group package',    '300 to 5000');
insert into Ticket_Category	values (6,	'All Inclusive Package',    '10000 to 50000');


insert into Venue	values (10050,	'Coffman Chapel',    '401 Rosemont Avenue', 'Frederick, MD', 100);
insert into Venue	values (10835,	'Robert F Kennedy Memorial Stadium',    '2400 East Capitol Street SE', 'Washington, DC', 45000);
insert into Venue	values (89373,	'UVA Scott Stadium',    '1815 Stadium Rd', 'Charlottesville, VA', 61500);
insert into Venue	values (68476,	'The Anthem',    '901 Wharf St SW', 'Washington, DC', 5000);
insert into Venue	values (42069,	'The Filmore Silver Spring',    '8656 Colesville Rd', 'Silver Spring, MD', 6000);
insert into Venue	values (17389,	'Balitmore Sound Stage',    '124 Market Pl', 'Baltimore, MD', 7500);

insert into Artist	values (101,	'Chris Brown',  16);
insert into Artist	values (215,    'Taylor Swift', 1);
insert into Artist	values (102,	'Billie Eilish',    12);
insert into Artist	values (305,	'50 Cent',	3);
insert into Artist	values (201,	'Drake',	16);
insert into Artist	values (403,	'Adele',  1);
insert into Artist	values (301,    'The Rolling Stones', 6);
insert into Artist	values (825,	'Bob Marley',    15);
insert into Artist	values (963,	'Travis Scott',	5);
insert into Artist	values (999,	'Skrillex',	7);

insert into Song	values (10886761,	'Iffy', 'Chris Brown',  '00:03:11',   16);
insert into Song	values (21757475,   'Shake It Off', 'Taylor Swift',  '00:04:02',  1);
insert into Song	values (10456462,	'Happier Than Ever',    'Billie Eilish',    '00:04:57',   12);
insert into Song	values (30556325,	'In Da Club',    '50 Cent',	 '00:04:08',  3);
insert into Song	values (20346561,	"God's Plan",    'Drake',	'00:03:19',   16);
insert into Song	values (45233466,	'Easy On Me', 'Adele',  '00:03:44',   1);
insert into Song	values (94726343,   'Paint it Black', 'The Rolling Stones',  '00:03:46',  6);
insert into Song	values (34567893,	'Could You Be Loved',    'Bob Marley',    '00:03:56',   15);
insert into Song	values (51234712,	'Goosebumps',    'Travis Scott',	 '00:04:11',  5);
insert into Song	values (87963621,	"Scary Monsters, Nice Sprites",    'Skrillex',	'00:04:03',   7);

insert into Customer_Order	values (8270,   '11:36:35',   '2022-04-28',   50,   'Gaithersburg, MD', 'cfo2@hood.edu',    10209);
insert into Customer_Order	values (2430,   '15:22:49',   '2021-12-11',   700,  'Frederick, MD',    'nar2@hood.edu',    10409);
insert into Customer_Order	values (5460,   '03:46:26',   '2022-01-23',   750,  'Frederick, MD',    'eno1@hood.edu',    10255);
insert into Customer_Order	values (5673,   '11:36:35',   '2021-04-27',   65,   'West Minster, MD', 'efb6@hood.edu',    10346);
insert into Customer_Order	values (8123,   '15:22:49',   '2022-03-12',   80,  'Leesburg, VA',    'sac5@hood.edu',    10499);
insert into Customer_Order	values (7543,   '03:46:26',   '2021-11-27',   10250,  'Hagerstown, MD',    'lid6@hood.edu',    10259);

insert into Concert values (1088761,	'2022-08-01', 'Coachella',  201,   89373);
insert into Concert values (2157475,    '2022-10-21', 'Fall Festival',  215,  10835);
insert into Concert	values (1046462,	'2022-11-15',    'Veteran Day Special',    305,   10050);
insert into Concert	values (3056325,	'2023-01-03',    'New Year Festival',	 102,  10835);
insert into Concert	values (2046561,	'2023-02-15',    'Valentine Concert',	101,   89373);
insert into Concert	values (1234567,	'2023-03-18',    'Halloween Spooky Concert',	101,   89373);

insert into Ticket	values (10886761,	'Pit', '2022-04-15',  1088761,   2);
insert into Ticket	values (21757475,   'Section G', '2022-03-29',  2157475,  3);
insert into Ticket	values (10456462,	'Section E',  '2022-01-19',    1046462,   2);
insert into Ticket	values (30556325,	'Pit',  '2021-11-05',	 3056325,  4);
insert into Ticket	values (20346561,	'Section B',  '2022-02-04',	2046561,   1);
insert into Ticket	values (20453421,	'Section A',  '2021-06-05',	1234567,   6);

insert into Order_Ticket	values (10133872,   10209,  10886761);
insert into Order_Ticket	values (21527992,   10409,  21757475);
insert into Order_Ticket    values (21427992,   10409,  10456462);
insert into Order_Ticket	values (10334566,	10346,  30556325);
insert into Order_Ticket	values (40928342,	10499,  20346561);
insert into Order_Ticket	values (30257495,	10259,  20453421);
