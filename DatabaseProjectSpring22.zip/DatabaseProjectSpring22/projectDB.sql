/* Elijah, Nathan and Chriss

Database Project
Spring 2022
CS 329
Prof. Dong

*/


use team10db;


DROP TABLE IF EXISTS Order_Ticket;
DROP TABLE IF EXISTS Ticket;
DROP TABLE IF EXISTS Concert;
DROP TABLE IF EXISTS Customer_Order;
DROP TABLE IF EXISTS Song;
DROP TABLE IF EXISTS Artist;
DROP TABLE IF EXISTS Venue;
DROP TABLE IF EXISTS Ticket_Category;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS Genre;


CREATE TABLE Genre (

g_id 	int,
g_name 	CHAR(30) not null,
PRIMARY KEY (g_id)
);


CREATE TABLE Customer (

cust_id 	int unique,
email 		VARCHAR(200),
username 	VARCHAR(200) NOT NULL UNIQUE,
password 	VARCHAR(200) NOT NULL,
PRIMARY KEY (cust_id)

);


CREATE TABLE Ticket_Category (

tc_id 			int unique,
tc_Desc 		VARCHAR(500),
tc_Price_Range	VARCHAR(200),
PRIMARY KEY (tc_id)

);

CREATE TABLE Venue (

v_id 		int,
v_name 		VARCHAR(200),
v_Address 	VARCHAR(200),
v_city 		VARCHAR(95),  
v_capacity 	int,
PRIMARY KEY (v_id)

);


CREATE TABLE Artist (

a_id 	int unique,
a_name 	VARCHAR(30),
g_id 	int,
PRIMARY KEY (a_id),
FOREIGN KEY (g_id) REFERENCES Genre (g_id)

);


CREATE TABLE Song (

s_id 		int unique,
s_name 		VARCHAR(30),
a_name      VARCHAR(30),
s_length 	TIME,
g_id 		int,
PRIMARY KEY (s_id),
FOREIGN KEY (g_id) REFERENCES Genre (g_id)

);

CREATE TABLE Customer_Order (

co_id 			int unique,  
order_time 		TIME,
co_date 		DATE,
total_price 	FLOAT,
address 		VARCHAR(200),   
delivery_email 	VARCHAR(200),
cust_id 		int,
PRIMARY KEY (co_id),
FOREIGN KEY (cust_id) REFERENCES Customer (cust_id)

);

  

CREATE TABLE Concert (

c_id 	int unique,   
c_date 	DATE,
c_name 	VARCHAR(50),
a_id 	int,
v_id 	int,
PRIMARY KEY (c_id),
FOREIGN KEY (a_id) REFERENCES Artist (a_id),
FOREIGN KEY (v_id) REFERENCES Venue (v_id)

);

CREATE TABLE Ticket (

t_id 			int unique,
t_seat 			VARCHAR(50),
t_Purchase_Date DATE,
c_id 			int,     
tc_id 			int,
PRIMARY KEY (t_id),
FOREIGN KEY (c_id) REFERENCES Concert (c_id),
FOREIGN KEY (tc_id) REFERENCES Ticket_Category (tc_id)

);

  


CREATE TABLE Order_Ticket (

o_id 	int unique,
cust_id int,
t_id 	int,
PRIMARY KEY (o_id),
FOREIGN KEY (cust_id) REFERENCES Customer (cust_id),
FOREIGN KEY (t_id) REFERENCES Ticket (t_id) 

);