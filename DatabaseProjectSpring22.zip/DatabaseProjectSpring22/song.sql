insert into Song	values (10886761,	'Iffy', 'Chris Brown',  '00:03:11',   16);
insert into Song	values (21757475,   'Shake It Off', 'Taylor Swift',  '00:04:02',  1);
insert into Song	values (10456462,	'Happier Than Ever',    'Billie Eilish',    '00:04:57',   12);
insert into Song	values (30556325,	'In Da Club',    '50 Cent',	 '00:04:08',  3);
insert into Song	values (20346561,	"God's Plan",    'Drake',	'00:03:19',   16);