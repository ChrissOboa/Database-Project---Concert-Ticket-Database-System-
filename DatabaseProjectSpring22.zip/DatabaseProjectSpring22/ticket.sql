insert into Ticket	values (10886761,	'Pit', 04-15-2022,  1088761,   2);
insert into Ticket	values (21757475,   'G45', 03-29-2022,  2157475,  3);
insert into Ticket	values (10456462,	'E62',  01-19-2022,    1046462,   2);
insert into Ticket	values (30556325,	'Pit',  11-05-2021,	 3056325,  4);
insert into Ticket	values (20346561,	'A34',  02-04-2022,	2046561,   1);