insert into Ticket_Category	values (1,	'VIP',    '3000 to 10000');
insert into Ticket_Category	values (2,	'General Admission',    '50 to 120');
insert into Ticket_Category	values (3,	'Early Birds',    '40 to 49');
insert into Ticket_Category	values (4,	'Reserved seating',    '600 to 1000');
insert into Ticket_Category	values (5,	'Group package',    '300 to 5000');