insert into Venue	values (10050,	'Coffman Chapel',    '401 Rosemont Avenue', 'Frederick, MD', 100);
insert into Venue	values (10835,	'Robert F Kennedy Memorial Stadium',    '2400 East Capitol Street SE', 'Washington DC', 45000);
insert into Venue	values (89373,	'UVA Scott Stadium',    '1815 Stadium Rd', 'Charlottesville, VA', 61500);